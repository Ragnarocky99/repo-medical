/**
 * @module ol/pixel
 */
/**
 * An array with two elements, representing a pixel. The first element is the
 * x-coordinate, the second the y-coordinate of the pixel.
 * @typedef {Array<number>} Pixel
 * @api
 */
export let nothing: any;
/**
 * An array with two elements, representing a pixel. The first element is the
 * x-coordinate, the second the y-coordinate of the pixel.
 */
export type Pixel = Array<number>;
//# sourceMappingURL=pixel.d.ts.map